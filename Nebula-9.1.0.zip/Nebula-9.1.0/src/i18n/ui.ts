import en_US from "./en_US.json";
import jp from "./jp.json";

export const defaultLang = "en_US";

export const ui = {
    en_US,
    jp
};
